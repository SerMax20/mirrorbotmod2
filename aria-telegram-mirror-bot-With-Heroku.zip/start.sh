chmod +x aria.sh && npm install && tsc && ./aria.sh && npm start
